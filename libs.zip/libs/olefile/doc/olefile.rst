=====================
olefile API Reference
=====================

Indices and tables
------------------

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

Summary
-------

.. autosummary::
    olefile.isOleFile
    olefile.OleFileIO
    olefile.OleMetadata
    olefile.enable_logging


olefile module
--------------

.. automodule:: olefile
    :members:
    :undoc-members:
    :show-inheritance:


