# -*- coding: utf8 -*-
import os, sys, subprocess, __init__

libs = ["olefile", "xlrd-1.1.0", "xlutils-2.0.0"]

def installLib(home, lib, url):
	folder = home + lib
	print("Installing %s ..." %(lib))
	if (os.path.exists(folder)):
		os.chdir(folder)
		subprocess.call(['python', 'setup.py', 'install'])
	else:
		print("Please download library from '%s'"%(url))
		print("and unpack it into home '%s'!" %(folder))

def uninstallLibs():
	global libs
	folder = os.path.dirname(os.path.abspath(__init__.__file__)) + os.path.sep
	print folder
	for lib in libs:
		print "Uninstalling '%s'..." %(lib)
		os.chdir(folder + lib)
		subprocess.call(['python', 'setup.py', 'uninstall'])

if __name__ == '__main__':
	home = os.path.dirname(os.path.abspath(Init.__file__)) + os.path.sep
	url = None
	try:
		home = sys.argv[1] + "libs" + os.path.sep
		url  = sys.argv[2]
		libs = [sys.argv[3]]
	except:
		pass

	for lib in libs:
		installLib(home, lib, url)
