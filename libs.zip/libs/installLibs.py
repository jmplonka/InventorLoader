# -*- coding: utf8 -*-
import os
import sys
import subprocess

if __name__ == '__main__':
	home = "./"
	url = None
	folders = ["olefile", "xlrd-1.1.0", "xlutils-2.0.0", "xlwt-1.3.0"]
	try:
		home = sys.argv[1] + "Mod/InventorLoader/libs/"
		url  = [sys.argv[2]]
		folders = [sys.argv[3]]
	except:
		pass
	
	os.chdir(home)
	home = os.getcwd() + '/'
	for folder in folders:
		print("Installing %s ..." %(folder))
		if (os.path.exists(home + folder)):
			os.chdir(home + folder)
			subprocess.call(['python', 'setup.py', 'install'])
		else:
			print("Please download library from '%s'"%(url))
			print("and unpack it into home '%s'!" %(home + folder))
