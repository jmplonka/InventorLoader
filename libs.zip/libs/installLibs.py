# -*- coding: utf-8 -*-
import os, sys, subprocess, __init__, FreeCAD

libs = ["olefile", "xlwt-1.3.0", "xlrd-1.1.0", "xlutils-2.0.0"]

def installLib(home, lib, url):
	folder = home + lib
	FreeCAD.Console.PrintWarning("Installing required side-package '%s' ..." %(lib))
	if (os.path.exists(folder)):
		os.chdir(folder)
		subprocess.call(['python', 'setup.py', 'install'])
		FreeCAD.Console.PrintWarning("DONE!\n")
	else:
		FreeCAD.Console.PrintError("Please download library from '%s' and unpack it into '%s'!\n"%(url, folder))

def uninstallLibs():
	global libs
	folder = os.path.dirname(os.path.abspath(__init__.__file__)) + os.path.sep
	for lib in libs:
		FreeCAD.Console.PrintWarning("Uninstalling '%s'..." %(lib))
		os.chdir(folder + lib)
		subprocess.call(['python', 'setup.py', 'uninstall'])
		FreeCAD.Console.PrintWarning("DONE!\n")

if __name__ == '__main__':
	home = os.path.dirname(os.path.abspath(__init__.__file__)) + os.path.sep
	url = None
	try:
		home = sys.argv[1] + "libs" + os.path.sep
		url  = sys.argv[2]
		libs = [sys.argv[3]]
	except:
		pass

	for lib in libs:
		installLib(home, lib, url)
