xlutils.display
===============

This module contains the :func:`quoted_sheet_name` and
:func:`cell_display` functions that allow easy and safe display of 
information returned by :class:`xlrd`.

The :doc:`api` contains examples of their use.
